import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import InlineQuery, MenuButtonWebApp, Message, CallbackQuery, WebAppInfo
from aiohttp import web

from app.bot import Access, router
from app.config import load_config
from app.core import Core
from app.db import Database
from app.wallet import AddressBook
from app.watcher import Watcher
from app.web import create_web_app


async def main():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    cfg = load_config()
    db = Database(cfg.db_path)
    await db.init()

    bot = Bot(cfg.bot_token, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    me = await bot.get_me()
    core = Core(cfg, db, AddressBook(cfg.xpubs), bot, me.username)

    dp = Dispatcher(storage=MemoryStorage())
    dp["core"] = core
    access = Access(core)
    for observer in (dp.message, dp.callback_query, dp.inline_query):
        observer.outer_middleware(access)
    dp.include_router(router)

    runner = web.AppRunner(create_web_app(core))
    await runner.setup()
    await web.TCPSite(runner, cfg.web_host, cfg.web_port).start()
    logging.info("Web UI: %s:%s  (public: %s)", cfg.web_host, cfg.web_port, cfg.webapp_url or "не задан")

    if cfg.webapp_url:
        await bot.set_chat_menu_button(menu_button=MenuButtonWebApp(text="Nemoice", web_app=WebAppInfo(url=cfg.webapp_url)))

    watcher = asyncio.create_task(Watcher(core).run())
    await bot.delete_webhook(drop_pending_updates=True)
    logging.info("Nemoice Wallet запущен как @%s", me.username)
    try:
        await dp.start_polling(bot)
    finally:
        watcher.cancel()
        await runner.cleanup()
        await db.close()
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
