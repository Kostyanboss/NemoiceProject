import asyncio
import secrets
import time
from contextlib import asynccontextmanager

import aiosqlite

from .common import UserError, fmt

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tg_id INTEGER UNIQUE NOT NULL,
    username TEXT,
    first_name TEXT,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS allowlist(tg_id INTEGER PRIMARY KEY);
CREATE TABLE IF NOT EXISTS balances(
    user_id INTEGER NOT NULL, asset TEXT NOT NULL, amount INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY(user_id, asset)
);
CREATE TABLE IF NOT EXISTS addresses(
    user_id INTEGER NOT NULL, chain TEXT NOT NULL, address TEXT UNIQUE NOT NULL, idx INTEGER NOT NULL,
    PRIMARY KEY(user_id, chain)
);
CREATE TABLE IF NOT EXISTS deposits(
    key TEXT PRIMARY KEY, user_id INTEGER NOT NULL, asset TEXT NOT NULL,
    amount INTEGER NOT NULL, txid TEXT, created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS transactions(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, type TEXT NOT NULL,
    asset TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT, created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS tx_user ON transactions(user_id, id DESC);
CREATE TABLE IF NOT EXISTS checks(
    code TEXT PRIMARY KEY, creator_id INTEGER NOT NULL, asset TEXT NOT NULL, amount INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'active', redeemed_by INTEGER,
    created_at INTEGER NOT NULL, redeemed_at INTEGER
);
CREATE TABLE IF NOT EXISTS withdrawals(
    id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, asset TEXT NOT NULL,
    address TEXT NOT NULL, amount INTEGER NOT NULL, fee INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending', txid TEXT, created_at INTEGER NOT NULL
);
"""


def display_name(row) -> str:
    if row["username"]:
        return "@" + row["username"]
    return row["first_name"] or str(row["tg_id"])


class Database:
    """Один SQLite-коннект + общий lock: все операции с балансами атомарны."""

    def __init__(self, path: str):
        self.path = path
        self.conn: aiosqlite.Connection | None = None
        self.lock = asyncio.Lock()

    async def init(self):
        self.conn = await aiosqlite.connect(self.path, isolation_level=None)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.execute("PRAGMA journal_mode=WAL")
        await self.conn.executescript(SCHEMA)

    async def close(self):
        if self.conn:
            await self.conn.close()

    # ---------- helpers ----------
    @asynccontextmanager
    async def tx(self):
        async with self.lock:
            await self.conn.execute("BEGIN IMMEDIATE")
            try:
                yield self.conn
            except BaseException:
                await self.conn.execute("ROLLBACK")
                raise
            else:
                await self.conn.execute("COMMIT")

    async def _one(self, sql, args=()):
        async with self.lock:
            cur = await self.conn.execute(sql, args)
            return await cur.fetchone()

    async def _all(self, sql, args=()):
        async with self.lock:
            cur = await self.conn.execute(sql, args)
            return await cur.fetchall()

    @staticmethod
    async def _add(c, user_id: int, asset: str, delta: int):
        await c.execute("INSERT OR IGNORE INTO balances(user_id,asset,amount) VALUES(?,?,0)", (user_id, asset))
        if delta < 0:
            cur = await c.execute(
                "UPDATE balances SET amount=amount+? WHERE user_id=? AND asset=? AND amount>=?",
                (delta, user_id, asset, -delta))
            if cur.rowcount == 0:
                raise UserError("Недостаточно средств")
        else:
            await c.execute("UPDATE balances SET amount=amount+? WHERE user_id=? AND asset=?",
                            (delta, user_id, asset))

    @staticmethod
    async def _log(c, user_id, typ, asset, amount, note=None):
        await c.execute(
            "INSERT INTO transactions(user_id,type,asset,amount,note,created_at) VALUES(?,?,?,?,?,?)",
            (user_id, typ, asset, amount, note, int(time.time())))

    # ---------- users / access ----------
    async def upsert_user(self, tg_id, username, first_name):
        async with self.tx() as c:
            await c.execute(
                "INSERT INTO users(tg_id,username,first_name,created_at) VALUES(?,?,?,?) "
                "ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name",
                (tg_id, (username or "").lower() or None, first_name, int(time.time())))
            cur = await c.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,))
            return await cur.fetchone()

    async def user_by_id(self, uid):
        return await self._one("SELECT * FROM users WHERE id=?", (uid,))

    async def find_user(self, ref: str):
        ref = ref.strip()
        if ref.lstrip("@").isdigit() and not ref.startswith("@"):
            return await self._one("SELECT * FROM users WHERE tg_id=?", (int(ref),))
        return await self._one("SELECT * FROM users WHERE username=?", (ref.lstrip("@").lower(),))

    async def allow(self, tg_id: int, on: bool):
        async with self.tx() as c:
            if on:
                await c.execute("INSERT OR IGNORE INTO allowlist(tg_id) VALUES(?)", (tg_id,))
            else:
                await c.execute("DELETE FROM allowlist WHERE tg_id=?", (tg_id,))

    async def in_allowlist(self, tg_id: int) -> bool:
        return await self._one("SELECT 1 FROM allowlist WHERE tg_id=?", (tg_id,)) is not None

    async def all_users(self):
        return await self._all("SELECT * FROM users ORDER BY id")

    # ---------- addresses / balances ----------
    async def addresses(self, user_id) -> dict:
        rows = await self._all("SELECT chain,address FROM addresses WHERE user_id=?", (user_id,))
        return {r["chain"]: r["address"] for r in rows}

    async def save_address(self, user_id, chain, address, idx):
        async with self.tx() as c:
            await c.execute("INSERT OR IGNORE INTO addresses(user_id,chain,address,idx) VALUES(?,?,?,?)",
                            (user_id, chain, address, idx))

    async def chain_addresses(self, chain):
        rows = await self._all("SELECT user_id,address FROM addresses WHERE chain=?", (chain,))
        return [(r["user_id"], r["address"]) for r in rows]

    async def balances(self, user_id) -> dict:
        rows = await self._all("SELECT asset,amount FROM balances WHERE user_id=?", (user_id,))
        return {r["asset"]: r["amount"] for r in rows}

    # ---------- deposits ----------
    async def credit_deposit(self, key, user_id, asset, amount, txid, note) -> bool:
        async with self.tx() as c:
            cur = await c.execute(
                "INSERT OR IGNORE INTO deposits(key,user_id,asset,amount,txid,created_at) VALUES(?,?,?,?,?,?)",
                (key, user_id, asset, amount, txid, int(time.time())))
            if cur.rowcount == 0:
                return False
            await self._add(c, user_id, asset, amount)
            await self._log(c, user_id, "deposit", asset, amount, note)
            return True

    # ---------- transfers ----------
    async def transfer(self, from_id, to_id, asset, amount):
        async with self.tx() as c:
            a = await (await c.execute("SELECT * FROM users WHERE id=?", (from_id,))).fetchone()
            b = await (await c.execute("SELECT * FROM users WHERE id=?", (to_id,))).fetchone()
            await self._add(c, from_id, asset, -amount)
            await self._add(c, to_id, asset, amount)
            await self._log(c, from_id, "transfer_out", asset, -amount, "→ " + display_name(b))
            await self._log(c, to_id, "transfer_in", asset, amount, "← " + display_name(a))

    # ---------- checks ----------
    async def create_check(self, user_id, asset, amount) -> str:
        code = secrets.token_urlsafe(9)
        async with self.tx() as c:
            await self._add(c, user_id, asset, -amount)
            await c.execute("INSERT INTO checks(code,creator_id,asset,amount,created_at) VALUES(?,?,?,?,?)",
                            (code, user_id, asset, amount, int(time.time())))
            await self._log(c, user_id, "check_create", asset, -amount, "чек " + code[:6])
        return code

    async def get_check(self, code):
        return await self._one("SELECT * FROM checks WHERE code=?", (code,))

    async def redeem_check(self, code, user_id):
        async with self.tx() as c:
            row = await (await c.execute("SELECT * FROM checks WHERE code=?", (code,))).fetchone()
            if not row:
                raise UserError("Чек не найден")
            if row["status"] != "active":
                raise UserError("Чек уже использован или отменён")
            await c.execute("UPDATE checks SET status='redeemed', redeemed_by=?, redeemed_at=? WHERE code=?",
                            (user_id, int(time.time()), code))
            await self._add(c, user_id, row["asset"], row["amount"])
            await self._log(c, user_id, "check_redeem", row["asset"], row["amount"], "чек " + code[:6])
            return row

    async def cancel_check(self, code, user_id):
        async with self.tx() as c:
            row = await (await c.execute("SELECT * FROM checks WHERE code=?", (code,))).fetchone()
            if not row or row["creator_id"] != user_id:
                raise UserError("Чек не найден")
            if row["status"] != "active":
                raise UserError("Чек уже использован или отменён")
            await c.execute("UPDATE checks SET status='cancelled' WHERE code=?", (code,))
            await self._add(c, user_id, row["asset"], row["amount"])
            await self._log(c, user_id, "check_cancel", row["asset"], row["amount"], "чек " + code[:6])

    async def user_checks(self, user_id, limit=30):
        return await self._all("SELECT * FROM checks WHERE creator_id=? ORDER BY created_at DESC LIMIT ?",
                               (user_id, limit))

    async def active_checks(self, user_id):
        return await self._all("SELECT * FROM checks WHERE creator_id=? AND status='active' "
                               "ORDER BY created_at DESC LIMIT 20", (user_id,))

    # ---------- withdrawals ----------
    async def request_withdraw(self, user_id, asset, address, amount, fee) -> int:
        async with self.tx() as c:
            await self._add(c, user_id, asset, -(amount + fee))
            cur = await c.execute(
                "INSERT INTO withdrawals(user_id,asset,address,amount,fee,created_at) VALUES(?,?,?,?,?,?)",
                (user_id, asset, address, amount, fee, int(time.time())))
            await self._log(c, user_id, "withdraw", asset, -(amount + fee), "вывод #%d" % cur.lastrowid)
            return cur.lastrowid

    async def get_withdrawal(self, wid):
        return await self._one("SELECT * FROM withdrawals WHERE id=?", (wid,))

    async def pending_withdrawals(self):
        return await self._all("SELECT * FROM withdrawals WHERE status='pending' ORDER BY id")

    async def finish_withdraw(self, wid, ok: bool, txid=None):
        async with self.tx() as c:
            row = await (await c.execute("SELECT * FROM withdrawals WHERE id=?", (wid,))).fetchone()
            if not row or row["status"] != "pending":
                raise UserError("Заявка уже обработана")
            if ok:
                await c.execute("UPDATE withdrawals SET status='sent', txid=? WHERE id=?", (txid, wid))
            else:
                await c.execute("UPDATE withdrawals SET status='rejected' WHERE id=?", (wid,))
                total = row["amount"] + row["fee"]
                await self._add(c, row["user_id"], row["asset"], total)
                await self._log(c, row["user_id"], "withdraw_refund", row["asset"], total, "вывод #%d" % wid)
            return row

    # ---------- history / stats ----------
    async def history(self, user_id, limit=30):
        return await self._all("SELECT * FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT ?",
                               (user_id, limit))

    async def stats(self):
        users = (await self._one("SELECT COUNT(*) n FROM users"))["n"]
        totals = await self._all("SELECT asset, SUM(amount) s FROM balances GROUP BY asset")
        pend = (await self._one("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'"))["n"]
        return users, {r["asset"]: fmt(r["s"]) for r in totals}, pend
