"""Опрос блокчейнов: находит входящие платежи на адреса пользователей и зачисляет на баланс.
Источники (бесплатные, без ключей): TronGrid, mempool.space, Blockscout (Ethereum)."""
import asyncio
import logging
from decimal import Decimal

import aiohttp

from .common import ASSETS, fmt, raw_to_int, to_int

log = logging.getLogger("nemoice.watcher")

TRONGRID = "https://api.trongrid.io"
USDT_TRC20 = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"
MEMPOOL = "https://mempool.space/api"
BLOCKSCOUT = "https://eth.blockscout.com/api/v2"


class Watcher:
    def __init__(self, core):
        self.core, self.cfg, self.db = core, core.cfg, core.db

    async def run(self):
        timeout = aiohttp.ClientTimeout(total=20)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            self.http = session
            while True:
                for chain, fn in (("tron", self.scan_tron), ("btc", self.scan_btc), ("eth", self.scan_eth)):
                    try:
                        await self.scan(chain, fn)
                    except asyncio.CancelledError:
                        raise
                    except Exception as e:
                        log.warning("scan %s failed: %s", chain, e)
                await asyncio.sleep(self.cfg.poll_seconds)

    async def scan(self, chain, fn):
        addresses = await self.db.chain_addresses(chain)
        if chain == "btc" and addresses:
            async with self.http.get(f"{MEMPOOL}/blocks/tip/height") as r:
                self._tip = int(await r.text())
        for user_id, addr in addresses:
            try:
                found = await fn(addr)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("%s %s: %s", chain, addr, e)
                continue
            for key, asset, amount, txid, note in found:
                if amount < to_int(ASSETS[asset]["min_dep"]):
                    continue  # пыль / спам-переводы
                if await self.db.credit_deposit(key, user_id, asset, amount, txid, note):
                    user = await self.db.user_by_id(user_id)
                    log.info("deposit %s %s user=%s tx=%s", fmt(amount), asset, user_id, txid)
                    await self.core.notify(user["tg_id"],
                                           f"📥 Пополнение: <b>+{fmt(amount)} {asset}</b>\n"
                                           f"Сеть: {ASSETS[asset]['network']}\n<code>{txid}</code>")
            await asyncio.sleep(0.3)

    async def _get(self, url, **kw):
        async with self.http.get(url, **kw) as r:
            if r.status != 200:
                raise RuntimeError(f"HTTP {r.status} {url}")
            return await r.json()

    # ---- TRON: TRX + USDT (TRC-20) ----
    async def scan_tron(self, addr):
        hdr = {"TRON-PRO-API-KEY": self.cfg.trongrid_key} if self.cfg.trongrid_key else {}
        out = []
        j = await self._get(f"{TRONGRID}/v1/accounts/{addr}/transactions", headers=hdr,
                            params={"only_to": "true", "only_confirmed": "true", "limit": 50})
        for tx in j.get("data", []):
            if (tx.get("ret") or [{}])[0].get("contractRet") != "SUCCESS":
                continue
            c = tx["raw_data"]["contract"][0]
            if c["type"] != "TransferContract":
                continue
            amt = raw_to_int(c["parameter"]["value"]["amount"], 6)
            out.append((f"{tx['txID']}:trx", "TRX", amt, tx["txID"], "TRON"))
        j = await self._get(f"{TRONGRID}/v1/accounts/{addr}/transactions/trc20", headers=hdr,
                            params={"only_to": "true", "only_confirmed": "true", "limit": 50,
                                    "contract_address": USDT_TRC20})
        for t in j.get("data", []):
            if t.get("to") != addr or t.get("type") != "Transfer":
                continue
            if (t.get("token_info") or {}).get("address") != USDT_TRC20:
                continue
            out.append((f"{t['transaction_id']}:usdt", "USDT", raw_to_int(t["value"], 6),
                        t["transaction_id"], "TRC-20"))
        return out

    # ---- Bitcoin ----
    async def scan_btc(self, addr):
        tip = self._tip
        out = []
        for tx in await self._get(f"{MEMPOOL}/address/{addr}/txs"):
            st = tx.get("status", {})
            if not st.get("confirmed"):
                continue
            if tip - st["block_height"] + 1 < self.cfg.btc_confirmations:
                continue
            for n, vout in enumerate(tx["vout"]):
                if vout.get("scriptpubkey_address") == addr:
                    out.append((f"{tx['txid']}:{n}", "BTC", raw_to_int(vout["value"], 8), tx["txid"], "Bitcoin"))
        return out

    # ---- Ethereum (нативный ETH) ----
    async def scan_eth(self, addr):
        out = []
        j = await self._get(f"{BLOCKSCOUT}/addresses/{addr}/transactions", params={"filter": "to"})
        for tx in j.get("items", []):
            if ((tx.get("to") or {}).get("hash") or "").lower() != addr.lower():
                continue
            if tx.get("result") != "success" or int(tx.get("confirmations") or 0) < self.cfg.eth_confirmations:
                continue
            if Decimal(tx.get("value") or 0) <= 0:
                continue
            out.append((f"{tx['hash']}:eth", "ETH", raw_to_int(tx["value"], 18), tx["hash"], "Ethereum"))
        return out
