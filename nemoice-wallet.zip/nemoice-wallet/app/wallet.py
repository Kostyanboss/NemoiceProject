from bip_utils import Bip44, Bip44Changes, Bip44Coins, Bip84, Bip84Coins


class AddressBook:
    """Создаёт адреса пополнения из публичных xpub.
    Приватных ключей здесь нет: бот умеет только принимать, не тратить."""

    def __init__(self, xpubs: dict):
        self._ctx = {
            "tron": Bip44.FromExtendedKey(xpubs["tron"], Bip44Coins.TRON),
            "btc": Bip84.FromExtendedKey(xpubs["btc"], Bip84Coins.BITCOIN),
            "eth": Bip44.FromExtendedKey(xpubs["eth"], Bip44Coins.ETHEREUM),
        }

    def address(self, chain: str, index: int) -> str:
        node = self._ctx[chain].Change(Bip44Changes.CHAIN_EXT).AddressIndex(index)
        return node.PublicKey().ToAddress()
