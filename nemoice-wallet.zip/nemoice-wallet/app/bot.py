import time
from datetime import datetime

from aiogram import BaseMiddleware, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (BufferedInputFile, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup,
                           InlineQuery, InlineQueryResultArticle, InlineQueryResultsButton,
                           InputTextMessageContent, Message, WebAppInfo)

from .common import ASSETS, CHAINS, UserError, asset_of, fmt, qr_png
from .core import Core
from .db import display_name

router = Router()

TYPES = {
    "deposit": "📥 Пополнение", "transfer_in": "💸 Получено", "transfer_out": "💸 Отправлено",
    "check_create": "🧾 Создан чек", "check_redeem": "🎁 Чек активирован", "check_cancel": "↩️ Чек отменён",
    "withdraw": "📤 Вывод", "withdraw_refund": "↩️ Возврат вывода",
}


class Send(StatesGroup):
    to = State()
    amount = State()


class Wd(StatesGroup):
    address = State()
    amount = State()
    confirm = State()


class Chk(StatesGroup):
    amount = State()


class AdminTx(StatesGroup):
    txid = State()


def btn(text, data=None, **kw):
    return InlineKeyboardButton(text=text, callback_data=data, **kw)


def kb(*rows):
    return InlineKeyboardMarkup(inline_keyboard=[list(r) for r in rows])


BACK = [btn("⬅️ Меню", "menu")]


def asset_kb(prefix):
    codes = list(ASSETS)
    rows = [[btn(f"{ASSETS[c]['sym']} {c}", f"{prefix}:{c}") for c in codes[i:i + 2]] for i in range(0, len(codes), 2)]
    rows.append(BACK)
    return kb(*rows)


def menu_kb(core: Core):
    rows = []
    if core.cfg.webapp_url:
        rows.append([InlineKeyboardButton(text="🌐 Открыть Nemoice", web_app=WebAppInfo(url=core.cfg.webapp_url))])
    rows += [[btn("💼 Кошелёк", "wallet")],
             [btn("📥 Пополнить", "dep"), btn("📤 Вывести", "wd")],
             [btn("💸 Перевести", "send"), btn("🧾 Чеки", "chk")],
             [btn("📜 История", "hist")]]
    return kb(*rows)


async def show(event, text, markup=None):
    """Редактирует сообщение (для callback) или отправляет новое."""
    if isinstance(event, CallbackQuery):
        try:
            await event.message.edit_text(text, reply_markup=markup)
        except TelegramBadRequest as e:
            if "not modified" not in str(e):
                await event.message.answer(text, reply_markup=markup)
        await event.answer()
    else:
        await event.answer(text, reply_markup=markup)


# ---------------- access middleware ----------------
class Access(BaseMiddleware):
    def __init__(self, core: Core):
        self.core = core

    async def __call__(self, handler, event, data):
        tg = data.get("event_from_user")
        if tg is None or tg.is_bot:
            return
        if not await self.core.is_allowed(tg.id):
            text = f"🔒 Nemoice Wallet — закрытый кошелёк.\nТвой ID: <code>{tg.id}</code> — отправь его админу."
            if isinstance(event, Message):
                await event.answer(text)
            elif isinstance(event, CallbackQuery):
                await event.answer("Доступ закрыт", show_alert=True)
            elif isinstance(event, InlineQuery):
                await event.answer([], cache_time=5, is_personal=True)
            return
        data["user"] = await self.core.db.upsert_user(tg.id, tg.username, tg.first_name)
        return await handler(event, data)


# ---------------- start / menu ----------------
async def menu_text(core, user):
    p = await core.portfolio(user)
    return (f"<b>Nemoice Wallet</b>\nПривет, {display_name(user)}\n\n"
            f"Баланс ≈ <b>${p['total_usd']:,.2f}</b>")


@router.message(CommandStart())
async def start(m: Message, command: CommandObject, core: Core, user, state: FSMContext):
    await state.clear()
    arg = command.args or ""
    if arg.startswith("c_"):
        try:
            row = await core.redeem_check(user, arg[2:])
            await m.answer(f"🎁 Чек активирован!\nТебе зачислено <b>{fmt(row['amount'])} {row['asset']}</b>")
        except UserError as e:
            await m.answer(f"⚠️ {e}")
    elif arg == "chk":
        return await m.answer("🧾 <b>Чеки</b>", reply_markup=chk_menu_kb())
    await m.answer(await menu_text(core, user), reply_markup=menu_kb(core))


@router.callback_query(F.data == "menu")
async def menu(cb: CallbackQuery, core: Core, user, state: FSMContext):
    await state.clear()
    await show(cb, await menu_text(core, user), menu_kb(core))


@router.callback_query(F.data == "wallet")
async def wallet(cb: CallbackQuery, core: Core, user):
    p = await core.portfolio(user)
    lines = []
    for it in p["items"]:
        usd = f"  ≈ ${it['usd']:,.2f}" if it["usd"] is not None else ""
        lines.append(f"{it['sym']} <b>{it['asset']}</b>  {it['balance']}{usd}")
    text = f"💼 <b>Кошелёк</b>\nИтого ≈ <b>${p['total_usd']:,.2f}</b>\n\n" + "\n".join(lines)
    await show(cb, text, kb([btn("📥 Пополнить", "dep"), btn("📤 Вывести", "wd")], BACK))


# ---------------- deposit ----------------
@router.callback_query(F.data == "dep")
async def dep(cb: CallbackQuery):
    await show(cb, "📥 <b>Пополнение</b>\nВыбери монету:", asset_kb("dep"))


@router.callback_query(F.data.startswith("dep:"))
async def dep_asset(cb: CallbackQuery, core: Core, user):
    asset = asset_of(cb.data.split(":")[1])
    meta = ASSETS[asset]
    addr = (await core.addresses(user))[meta["chain"]]
    caption = (f"📥 <b>Пополнение {asset}</b>\nСеть: <b>{meta['network']}</b>\n\n"
               f"<code>{addr}</code>\n\n"
               f"Минимум: {meta['min_dep']} {asset}. Присылай только {asset} в сети {meta['network']} — "
               f"иначе средства потеряются. Зачисление придёт уведомлением.")
    await cb.message.answer_photo(BufferedInputFile(qr_png(addr), "qr.png"), caption=caption,
                                  reply_markup=kb(BACK))
    await cb.answer()


# ---------------- transfer ----------------
@router.callback_query(F.data == "send")
async def send(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, "💸 <b>Перевод внутри Nemoice</b>\nМгновенно и без комиссии. Выбери монету:", asset_kb("send"))


@router.callback_query(F.data.startswith("send:"))
async def send_asset(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Send.to)
    await state.update_data(asset=asset_of(cb.data.split(":")[1]))
    await show(cb, "Кому? Пришли @username или Telegram ID.\nЧеловек должен хотя бы раз запустить бота.", kb(BACK))


@router.message(Send.to)
async def send_to(m: Message, state: FSMContext, core: Core, user):
    target = await core.db.find_user(m.text or "")
    if not target or target["id"] == user["id"]:
        return await m.answer("Не нашёл такого получателя. Попробуй ещё раз или вернись в меню.", reply_markup=kb(BACK))
    d = await state.get_data()
    await state.update_data(to=m.text.strip())
    await state.set_state(Send.amount)
    bal = (await core.db.balances(user["id"])).get(d["asset"], 0)
    await m.answer(f"Получатель: <b>{display_name(target)}</b>\nСколько {d['asset']}? Доступно: {fmt(bal)}",
                   reply_markup=kb(BACK))


@router.message(Send.amount)
async def send_amount(m: Message, state: FSMContext, core: Core, user):
    d = await state.get_data()
    try:
        target, asset, amount = await core.transfer(user, d["to"], d["asset"], m.text or "")
    except UserError as e:
        return await m.answer(f"⚠️ {e}", reply_markup=kb(BACK))
    await state.clear()
    await m.answer(f"✅ Отправлено <b>{fmt(amount)} {asset}</b> → {display_name(target)}", reply_markup=kb(BACK))


# ---------------- withdraw ----------------
@router.callback_query(F.data == "wd")
async def wd(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, "📤 <b>Вывод на внешний адрес</b>\nВыбери монету:", asset_kb("wd"))


@router.callback_query(F.data.startswith("wd:"))
async def wd_asset(cb: CallbackQuery, state: FSMContext):
    asset = asset_of(cb.data.split(":")[1])
    meta = ASSETS[asset]
    await state.set_state(Wd.address)
    await state.update_data(asset=asset)
    await show(cb, f"Пришли адрес получателя в сети <b>{meta['network']}</b>.\n"
                   f"Комиссия: {meta['fee']} {asset}, минимум: {meta['min_wd']} {asset}.", kb(BACK))


@router.message(Wd.address)
async def wd_address(m: Message, state: FSMContext):
    await state.update_data(address=(m.text or "").strip())
    await state.set_state(Wd.amount)
    await m.answer("Сколько отправить? (комиссия спишется сверху)", reply_markup=kb(BACK))


@router.message(Wd.amount)
async def wd_amount(m: Message, state: FSMContext, core: Core, user):
    from .common import to_int
    from .core import valid_address
    d = await state.get_data()
    meta = ASSETS[d["asset"]]
    try:
        amount = to_int(m.text or "")
        if not valid_address(meta["chain"], d["address"]):
            raise UserError(f"Это не адрес сети {meta['network']}. Вернись в меню и начни заново.")
        if amount < to_int(meta["min_wd"]):
            raise UserError(f"Минимум для вывода: {meta['min_wd']} {d['asset']}")
        fee = to_int(meta["fee"])
        bal = (await core.db.balances(user["id"])).get(d["asset"], 0)
        if bal < amount + fee:
            raise UserError(f"Недостаточно средств: нужно {fmt(amount + fee)} {d['asset']}, есть {fmt(bal)}")
    except UserError as e:
        return await m.answer(f"⚠️ {e}", reply_markup=kb(BACK))
    await state.update_data(amount=str(m.text))
    await state.set_state(Wd.confirm)
    await m.answer(f"Проверь вывод:\n\nСумма: <b>{fmt(amount)} {d['asset']}</b>\nКомиссия: {fmt(fee)}\n"
                   f"Сеть: {meta['network']}\nАдрес: <code>{d['address']}</code>",
                   reply_markup=kb([btn("✅ Отправить", "wd_ok"), btn("Отмена", "menu")]))


@router.callback_query(Wd.confirm, F.data == "wd_ok")
async def wd_ok(cb: CallbackQuery, state: FSMContext, core: Core, user):
    d = await state.get_data()
    await state.clear()
    try:
        wid, amount, fee = await core.withdraw(user, d["asset"], d["address"], d["amount"])
    except UserError as e:
        return await show(cb, f"⚠️ {e}", kb(BACK))
    await show(cb, f"⏳ Заявка #{wid} создана: <b>{fmt(amount)} {d['asset']}</b>.\n"
                   f"Админ отправит вывод вручную — пришлю уведомление с хэшем.", kb(BACK))


# ---------------- checks ----------------
def chk_menu_kb():
    return kb([btn("➕ Создать чек", "chk_new"), btn("📋 Мои чеки", "chk_list")], BACK)


@router.callback_query(F.data == "chk")
async def chk(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, "🧾 <b>Чеки</b>\nЧек — это ссылка на деньги: списываются сразу, "
                   "забрать может первый, кто её откроет.", chk_menu_kb())


@router.callback_query(F.data == "chk_new")
async def chk_new(cb: CallbackQuery):
    await show(cb, "Монета для чека:", asset_kb("chk_new"))


@router.callback_query(F.data.startswith("chk_new:"))
async def chk_new_asset(cb: CallbackQuery, state: FSMContext, core: Core, user):
    asset = asset_of(cb.data.split(":")[1])
    await state.set_state(Chk.amount)
    await state.update_data(asset=asset)
    bal = (await core.db.balances(user["id"])).get(asset, 0)
    await show(cb, f"На сколько {asset}? Доступно: {fmt(bal)}", kb(BACK))


def check_kb(core, code):
    return kb([InlineKeyboardButton(text="📤 Отправить в чат", switch_inline_query=code)],
              [InlineKeyboardButton(text="🔗 Ссылка", url=core.check_link(code))],
              [btn("❌ Отменить чек", f"chk_x:{code}")], BACK)


@router.message(Chk.amount)
async def chk_amount(m: Message, state: FSMContext, core: Core, user):
    d = await state.get_data()
    try:
        code, asset, amount = await core.create_check(user, d["asset"], m.text or "")
    except UserError as e:
        return await m.answer(f"⚠️ {e}", reply_markup=kb(BACK))
    await state.clear()
    await m.answer(f"🧾 Чек на <b>{fmt(amount)} {asset}</b> создан.\n\n{core.check_link(code)}",
                   reply_markup=check_kb(core, code))


@router.callback_query(F.data == "chk_list")
async def chk_list(cb: CallbackQuery, core: Core, user):
    rows = await core.db.user_checks(user["id"], 10)
    if not rows:
        return await show(cb, "Чеков пока нет.", chk_menu_kb())
    st = {"active": "🟢 активен", "redeemed": "✅ забран", "cancelled": "↩️ отменён"}
    lines, buttons = [], []
    for r in rows:
        lines.append(f"{fmt(r['amount'])} {r['asset']} — {st[r['status']]}")
        if r["status"] == "active":
            buttons.append([btn(f"❌ Отменить {fmt(r['amount'])} {r['asset']}", f"chk_x:{r['code']}")])
    await show(cb, "📋 <b>Твои чеки</b>\n\n" + "\n".join(lines), kb(*buttons, BACK))


@router.callback_query(F.data.startswith("chk_x:"))
async def chk_cancel(cb: CallbackQuery, core: Core, user):
    try:
        await core.db.cancel_check(cb.data.split(":", 1)[1], user["id"])
    except UserError as e:
        return await cb.answer(str(e), show_alert=True)
    await cb.answer("Чек отменён, деньги вернулись на баланс", show_alert=True)
    await chk_list(cb, core, user)


@router.inline_query()
async def inline(q: InlineQuery, core: Core, user):
    checks = await core.db.active_checks(user["id"])
    term = q.query.strip()
    if term:
        checks = [c for c in checks if c["code"] == term]
    results = []
    for c in checks:
        link = core.check_link(c["code"])
        results.append(InlineQueryResultArticle(
            id=c["code"], title=f"🧾 Чек на {fmt(c['amount'])} {c['asset']}", description="Отправить в этот чат",
            input_message_content=InputTextMessageContent(
                message_text=f"🧾 <b>Чек Nemoice</b>\n\nНа <b>{fmt(c['amount'])} {c['asset']}</b>\n"
                             f"Забрать может первый, кто нажмёт кнопку."),
            reply_markup=kb([InlineKeyboardButton(text="🎁 Забрать", url=link)])))
    await q.answer(results, cache_time=1, is_personal=True,
                   button=InlineQueryResultsButton(text="Создать чек", start_parameter="chk"))


# ---------------- history ----------------
@router.callback_query(F.data == "hist")
async def hist(cb: CallbackQuery, core: Core, user):
    rows = await core.db.history(user["id"], 12)
    if not rows:
        return await show(cb, "📜 Операций пока нет.", kb(BACK))
    lines = []
    for r in rows:
        sign = "+" if r["amount"] > 0 else ""
        when = datetime.fromtimestamp(r["created_at"]).strftime("%d.%m %H:%M")
        lines.append(f"{TYPES.get(r['type'], r['type'])}  <b>{sign}{fmt(r['amount'])} {r['asset']}</b>\n"
                     f"<i>{when} · {r['note'] or ''}</i>")
    await show(cb, "📜 <b>История</b>\n\n" + "\n\n".join(lines), kb(BACK))


# ---------------- admin ----------------
def admin_only(core: Core, m: Message) -> bool:
    return core.is_admin(m.from_user.id)


@router.message(Command("allow"))
async def allow(m: Message, command: CommandObject, core: Core):
    if not admin_only(core, m):
        return
    if not (command.args or "").strip().isdigit():
        return await m.answer("Использование: /allow 123456789")
    await core.db.allow(int(command.args), True)
    await m.answer(f"✅ {command.args} добавлен")


@router.message(Command("deny"))
async def deny(m: Message, command: CommandObject, core: Core):
    if not admin_only(core, m):
        return
    if not (command.args or "").strip().isdigit():
        return await m.answer("Использование: /deny 123456789")
    await core.db.allow(int(command.args), False)
    await m.answer(f"🚫 {command.args} удалён из доступа")


@router.message(Command("stats"))
async def stats(m: Message, core: Core):
    if not admin_only(core, m):
        return
    users, totals, pend = await core.db.stats()
    t = "\n".join(f"{k}: {v}" for k, v in totals.items()) or "—"
    await m.answer(f"📊 Пользователей: {users}\nЗаявок на вывод: {pend}\n\nОбщие балансы:\n{t}")


@router.message(Command("withdrawals"))
async def withdrawals(m: Message, core: Core):
    if not admin_only(core, m):
        return
    rows = await core.db.pending_withdrawals()
    if not rows:
        return await m.answer("Нет ожидающих заявок")
    for r in rows:
        await m.answer(f"📤 #{r['id']} {fmt(r['amount'])} {r['asset']}\n<code>{r['address']}</code>",
                       reply_markup=kb([btn("✅ Отправил", f"wdok:{r['id']}"), btn("❌ Отклонить", f"wdno:{r['id']}")]))


@router.callback_query(F.data.startswith("wdok:"))
async def wd_admin_ok(cb: CallbackQuery, state: FSMContext, core: Core):
    if not core.is_admin(cb.from_user.id):
        return await cb.answer("Только админ", show_alert=True)
    await state.set_state(AdminTx.txid)
    await state.update_data(wid=int(cb.data.split(":")[1]))
    await cb.message.answer("Пришли хэш транзакции (или «-», если без хэша):")
    await cb.answer()


@router.message(AdminTx.txid)
async def wd_admin_txid(m: Message, state: FSMContext, core: Core):
    if not admin_only(core, m):
        return
    d = await state.get_data()
    await state.clear()
    txid = None if (m.text or "").strip() == "-" else (m.text or "").strip()
    try:
        row = await core.db.finish_withdraw(d["wid"], True, txid)
    except UserError as e:
        return await m.answer(f"⚠️ {e}")
    u = await core.db.user_by_id(row["user_id"])
    await core.notify(u["tg_id"], f"✅ Вывод #{row['id']} <b>{fmt(row['amount'])} {row['asset']}</b> отправлен."
                                  + (f"\n<code>{txid}</code>" if txid else ""))
    await m.answer(f"Заявка #{row['id']} закрыта")


@router.callback_query(F.data.startswith("wdno:"))
async def wd_admin_no(cb: CallbackQuery, core: Core):
    if not core.is_admin(cb.from_user.id):
        return await cb.answer("Только админ", show_alert=True)
    try:
        row = await core.db.finish_withdraw(int(cb.data.split(":")[1]), False)
    except UserError as e:
        return await cb.answer(str(e), show_alert=True)
    u = await core.db.user_by_id(row["user_id"])
    await core.notify(u["tg_id"], f"❌ Вывод #{row['id']} отклонён, "
                                  f"<b>{fmt(row['amount'] + row['fee'])} {row['asset']}</b> вернулись на баланс.")
    await cb.message.edit_text(f"Заявка #{row['id']} отклонена, средства возвращены")
    await cb.answer()
