import logging
import re

from aiogram import Bot
from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from bip_utils import EthAddrDecoder, TrxAddrDecoder

from .common import ASSETS, CHAINS, Prices, UserError, asset_of, fmt, to_int
from .db import Database, display_name
from .wallet import AddressBook

log = logging.getLogger("nemoice")

BTC_RE = re.compile(r"^(bc1[a-z0-9]{25,60}|[13][a-km-zA-HJ-NP-Z1-9]{25,34})$")


def valid_address(chain: str, addr: str) -> bool:
    try:
        if chain == "tron":
            TrxAddrDecoder.DecodeAddr(addr)
            return True
        if chain == "eth":
            EthAddrDecoder.DecodeAddr(addr)
            return True
        return bool(BTC_RE.match(addr))
    except Exception:
        return False


class Core:
    """Вся бизнес-логика. Бот и веб-интерфейс ходят только сюда."""

    def __init__(self, cfg, db: Database, book: AddressBook, bot: Bot, bot_username: str):
        self.cfg, self.db, self.book, self.bot = cfg, db, book, bot
        self.bot_username = bot_username
        self.prices = Prices()

    # ---- access ----
    def is_admin(self, tg_id: int) -> bool:
        return tg_id in self.cfg.admin_ids

    async def is_allowed(self, tg_id: int) -> bool:
        if not self.cfg.private_mode or self.is_admin(tg_id):
            return True
        return await self.db.in_allowlist(tg_id)

    async def notify(self, tg_id: int, text: str, kb=None):
        try:
            await self.bot.send_message(tg_id, text, reply_markup=kb)
        except Exception as e:
            log.warning("notify %s failed: %s", tg_id, e)

    # ---- wallet ----
    async def addresses(self, user) -> dict:
        have = await self.db.addresses(user["id"])
        for chain in CHAINS:
            if chain not in have:
                addr = self.book.address(chain, user["id"])
                await self.db.save_address(user["id"], chain, addr, user["id"])
                have[chain] = addr
        return have

    async def portfolio(self, user) -> dict:
        bal = await self.db.balances(user["id"])
        prices = await self.prices.get()
        addrs = await self.addresses(user)
        items, total = [], 0.0
        for code, a in ASSETS.items():
            amt = bal.get(code, 0)
            price = prices.get(code)
            usd = (amt / 1e8) * price if price else None
            total += usd or 0
            items.append(dict(asset=code, name=a["name"], network=a["network"], chain=a["chain"],
                              color=a["color"], sym=a["sym"], amount=amt, balance=fmt(amt),
                              price=price, usd=usd, address=addrs[a["chain"]],
                              fee=a["fee"], min_wd=a["min_wd"], min_dep=a["min_dep"]))
        return dict(items=items, total_usd=total)

    # ---- transfer ----
    async def transfer(self, user, to_ref: str, asset: str, amount_text: str):
        asset, amount = asset_of(asset), to_int(amount_text)
        target = await self.db.find_user(to_ref)
        if not target:
            raise UserError("Получатель не найден. Он должен хотя бы раз запустить бота.")
        if target["id"] == user["id"]:
            raise UserError("Нельзя переводить самому себе")
        await self.db.transfer(user["id"], target["id"], asset, amount)
        await self.notify(target["tg_id"], f"💸 {display_name(user)} отправил тебе <b>{fmt(amount)} {asset}</b>")
        return target, asset, amount

    # ---- checks ----
    def check_link(self, code: str) -> str:
        return f"https://t.me/{self.bot_username}?start=c_{code}"

    async def create_check(self, user, asset: str, amount_text: str):
        asset, amount = asset_of(asset), to_int(amount_text)
        code = await self.db.create_check(user["id"], asset, amount)
        return code, asset, amount

    async def redeem_check(self, user, code: str):
        row = await self.db.redeem_check(code, user["id"])
        if row["creator_id"] != user["id"]:
            creator = await self.db.user_by_id(row["creator_id"])
            if creator:
                await self.notify(creator["tg_id"],
                                  f"🎁 {display_name(user)} забрал твой чек на <b>{fmt(row['amount'])} {row['asset']}</b>")
        return row

    # ---- withdraw ----
    async def withdraw(self, user, asset: str, address: str, amount_text: str):
        asset, amount = asset_of(asset), to_int(amount_text)
        meta, address = ASSETS[asset], address.strip()
        if not valid_address(meta["chain"], address):
            raise UserError(f"Это не похоже на адрес сети {meta['network']}")
        if amount < to_int(meta["min_wd"]):
            raise UserError(f"Минимум для вывода: {meta['min_wd']} {asset}")
        fee = to_int(meta["fee"])
        wid = await self.db.request_withdraw(user["id"], asset, address, amount, fee)
        kb = InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="✅ Отправил", callback_data=f"wdok:{wid}"),
            InlineKeyboardButton(text="❌ Отклонить", callback_data=f"wdno:{wid}"),
        ]])
        text = (f"📤 <b>Заявка на вывод #{wid}</b>\nОт: {display_name(user)}\n"
                f"Сумма: <b>{fmt(amount)} {asset}</b> ({meta['network']})\nКомиссия: {fmt(fee)} {asset}\n"
                f"Адрес: <code>{address}</code>")
        for admin in self.cfg.admin_ids:
            await self.notify(admin, text, kb)
        return wid, amount, fee
