import hashlib
import hmac
import json
import time
from datetime import datetime
from pathlib import Path
from urllib.parse import parse_qsl

from aiohttp import web

from .common import ASSETS, UserError, asset_of, fmt, qr_png
from .core import Core
from .db import display_name

INDEX = Path(__file__).resolve().parent.parent / "webapp" / "index.html"


def validate_init_data(init_data: str, token: str, max_age: int = 86400) -> dict:
    """Проверка подписи Telegram Mini App (https://core.telegram.org/bots/webapps#validating-data)."""
    pairs = dict(parse_qsl(init_data, keep_blank_values=True))
    got = pairs.pop("hash", None)
    if not got:
        raise ValueError("no hash")
    check = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    calc = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc, got):
        raise ValueError("bad hash")
    if time.time() - int(pairs.get("auth_date", "0")) > max_age:
        raise ValueError("expired")
    return json.loads(pairs["user"])


@web.middleware
async def errors(request, handler):
    try:
        return await handler(request)
    except UserError as e:
        return web.json_response({"error": str(e)}, status=400)
    except web.HTTPException:
        raise
    except Exception:
        request.app["log"].exception("web error")
        return web.json_response({"error": "Внутренняя ошибка"}, status=500)


@web.middleware
async def auth(request, handler):
    if not request.path.startswith("/api/") or request.path == "/api/qr":
        return await handler(request)
    core: Core = request.app["core"]
    try:
        tg = validate_init_data(request.headers.get("X-Init-Data", ""), core.cfg.bot_token)
    except Exception:
        return web.json_response({"error": "Открой кошелёк через бота в Telegram"}, status=401)
    if not await core.is_allowed(tg["id"]):
        return web.json_response({"error": "Доступ закрыт"}, status=403)
    request["user"] = await core.db.upsert_user(tg["id"], tg.get("username"), tg.get("first_name"))
    return await handler(request)


async def index(request):
    return web.FileResponse(INDEX, headers={"Cache-Control": "no-store"})


async def me(request):
    core: Core = request.app["core"]
    user = request["user"]
    p = await core.portfolio(user)
    for it in p["items"]:
        it.pop("amount")
    return web.json_response({
        "user": {"name": display_name(user), "first_name": user["first_name"]},
        "total_usd": p["total_usd"], "assets": p["items"],
        "bot": core.bot_username,
    })


async def history(request):
    core: Core = request.app["core"]
    rows = await core.db.history(request["user"]["id"], 50)
    return web.json_response([
        {"id": r["id"], "type": r["type"], "asset": r["asset"], "amount": fmt(r["amount"]),
         "positive": r["amount"] > 0, "note": r["note"] or "", "ts": r["created_at"]} for r in rows])


async def transfer(request):
    core: Core = request.app["core"]
    b = await request.json()
    target, asset, amount = await core.transfer(request["user"], str(b.get("to", "")),
                                                str(b.get("asset", "")), str(b.get("amount", "")))
    return web.json_response({"ok": True, "to": display_name(target), "asset": asset, "amount": fmt(amount)})


async def checks(request):
    core: Core = request.app["core"]
    rows = await core.db.user_checks(request["user"]["id"], 30)
    return web.json_response([
        {"code": r["code"], "asset": r["asset"], "amount": fmt(r["amount"]), "status": r["status"],
         "link": core.check_link(r["code"]), "ts": r["created_at"]} for r in rows])


async def check_create(request):
    core: Core = request.app["core"]
    b = await request.json()
    code, asset, amount = await core.create_check(request["user"], str(b.get("asset", "")), str(b.get("amount", "")))
    return web.json_response({"code": code, "asset": asset, "amount": fmt(amount), "link": core.check_link(code)})


async def check_cancel(request):
    core: Core = request.app["core"]
    b = await request.json()
    await core.db.cancel_check(str(b.get("code", "")), request["user"]["id"])
    return web.json_response({"ok": True})


async def check_redeem(request):
    core: Core = request.app["core"]
    b = await request.json()
    row = await core.redeem_check(request["user"], str(b.get("code", "")))
    return web.json_response({"asset": row["asset"], "amount": fmt(row["amount"])})


async def withdraw(request):
    core: Core = request.app["core"]
    b = await request.json()
    wid, amount, fee = await core.withdraw(request["user"], str(b.get("asset", "")),
                                           str(b.get("address", "")), str(b.get("amount", "")))
    return web.json_response({"id": wid, "amount": fmt(amount), "fee": fmt(fee)})


async def qr(request):
    data = request.query.get("data", "")
    if not data or len(data) > 120:
        raise web.HTTPBadRequest()
    return web.Response(body=qr_png(data), content_type="image/png", headers={"Cache-Control": "max-age=86400"})


def create_web_app(core: Core) -> web.Application:
    import logging
    app = web.Application(middlewares=[errors, auth])
    app["core"], app["log"] = core, logging.getLogger("nemoice.web")
    app.add_routes([
        web.get("/", index),
        web.get("/api/me", me),
        web.get("/api/history", history),
        web.post("/api/transfer", transfer),
        web.get("/api/checks", checks),
        web.post("/api/check", check_create),
        web.post("/api/check/cancel", check_cancel),
        web.post("/api/check/redeem", check_redeem),
        web.post("/api/withdraw", withdraw),
        web.get("/api/qr", qr),
    ])
    return app
