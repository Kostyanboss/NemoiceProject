import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


def _ids(v: str) -> set[int]:
    return {int(x) for x in v.replace(" ", "").split(",") if x}


@dataclass(frozen=True)
class Config:
    bot_token: str
    admin_ids: set[int]
    private_mode: bool
    xpubs: dict
    webapp_url: str
    web_host: str
    web_port: int
    db_path: str
    poll_seconds: int
    trongrid_key: str
    btc_confirmations: int
    eth_confirmations: int


def load_config() -> Config:
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("BOT_TOKEN не задан в .env")
    xpubs = {
        "tron": os.getenv("XPUB_TRON", "").strip(),
        "btc": os.getenv("XPUB_BTC", "").strip(),
        "eth": os.getenv("XPUB_ETH", "").strip(),
    }
    if not all(xpubs.values()):
        raise SystemExit("Заполни XPUB_TRON / XPUB_BTC / XPUB_ETH (запусти gen_seed.py)")
    return Config(
        bot_token=token,
        admin_ids=_ids(os.getenv("ADMIN_IDS", "")),
        private_mode=os.getenv("PRIVATE_MODE", "true").lower() in ("1", "true", "yes"),
        xpubs=xpubs,
        webapp_url=os.getenv("WEBAPP_URL", "").strip().rstrip("/"),
        web_host=os.getenv("WEB_HOST", "0.0.0.0"),
        web_port=int(os.getenv("WEB_PORT", "8080")),
        db_path=os.getenv("DB_PATH", "nemoice.db"),
        poll_seconds=int(os.getenv("POLL_SECONDS", "30")),
        trongrid_key=os.getenv("TRONGRID_KEY", "").strip(),
        btc_confirmations=int(os.getenv("BTC_CONFIRMATIONS", "2")),
        eth_confirmations=int(os.getenv("ETH_CONFIRMATIONS", "12")),
    )
