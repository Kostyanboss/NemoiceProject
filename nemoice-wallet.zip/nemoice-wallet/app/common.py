import io
import time
from decimal import ROUND_DOWN, Decimal, InvalidOperation

import aiohttp
import qrcode

# Внутри бота все суммы — целые числа в единицах 1e-8 (без ошибок округления float)
SCALE = 10**8


class UserError(Exception):
    """Ошибка, текст которой безопасно показать пользователю."""


ASSETS = {
    "USDT": dict(name="Tether", network="TRC-20", chain="tron", decimals=6, cg="tether",
                 fee="1", min_wd="5", min_dep="0.5", color="#3FBF9B", sym="₮"),
    "TRX": dict(name="Tron", network="TRON", chain="tron", decimals=6, cg="tron",
                fee="2", min_wd="10", min_dep="1", color="#F0605D", sym="T"),
    "BTC": dict(name="Bitcoin", network="Bitcoin", chain="btc", decimals=8, cg="bitcoin",
                fee="0.0001", min_wd="0.0005", min_dep="0.00002", color="#F7A23B", sym="₿"),
    "ETH": dict(name="Ethereum", network="Ethereum", chain="eth", decimals=18, cg="ethereum",
                fee="0.002", min_wd="0.005", min_dep="0.0002", color="#8E9CFF", sym="Ξ"),
}
CHAINS = {"tron": "TRON", "btc": "Bitcoin", "eth": "Ethereum"}


def to_int(text) -> int:
    """'12,5' -> 1250000000. Кидает UserError на мусор и неположительные суммы."""
    try:
        d = Decimal(str(text).strip().replace(",", ".").replace(" ", ""))
    except (InvalidOperation, ValueError):
        raise UserError("Введи сумму числом, например 12.5")
    if not d.is_finite():
        raise UserError("Введи сумму числом, например 12.5")
    if d > 10**9:
        raise UserError("Слишком большая сумма")
    d = d.quantize(Decimal("0.00000001"), rounding=ROUND_DOWN)
    if d <= 0:
        raise UserError("Сумма должна быть больше нуля")
    return int(d * SCALE)


def raw_to_int(raw, decimals: int) -> int:
    """Сумма из блокчейна (в минимальных единицах) -> внутренние единицы."""
    d = Decimal(str(raw)) / (Decimal(10) ** decimals)
    return int((d * SCALE).to_integral_value(ROUND_DOWN))


def fmt(v: int) -> str:
    s = format(Decimal(v) / SCALE, "f")
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s or "0"


def asset_of(code: str) -> str:
    code = (code or "").upper()
    if code not in ASSETS:
        raise UserError("Неизвестная монета")
    return code


def qr_png(data: str) -> bytes:
    buf = io.BytesIO()
    qrcode.make(data, box_size=8, border=2).save(buf, format="PNG")
    return buf.getvalue()


class Prices:
    """Курсы к USD с CoinGecko, кэш на 90 секунд. Если API недоступен — берём старый кэш."""

    def __init__(self):
        self._cache: dict[str, float] = {"USDT": 1.0}
        self._ts = 0.0

    async def get(self) -> dict[str, float]:
        if time.time() - self._ts < 90:
            return self._cache
        ids = ",".join(a["cg"] for a in ASSETS.values())
        try:
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=8)) as s:
                async with s.get("https://api.coingecko.com/api/v3/simple/price",
                                 params={"ids": ids, "vs_currencies": "usd"}) as r:
                    data = await r.json()
            fresh = {code: float(data[a["cg"]]["usd"]) for code, a in ASSETS.items() if a["cg"] in data}
            if fresh:
                self._cache = {**self._cache, **fresh}
        except Exception:
            pass
        self._ts = time.time()
        return self._cache
