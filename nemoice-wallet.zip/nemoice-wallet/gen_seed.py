"""Запусти ОДИН раз на своём компьютере. Мнемонику запиши на бумагу и не клади на сервер.
В .env нужны только три xpub — по ним бот создаёт адреса, но потратить с них ничего не может."""
from bip_utils import (
    Bip39MnemonicGenerator, Bip39SeedGenerator, Bip39WordsNum,
    Bip44, Bip44Coins, Bip84, Bip84Coins,
)

mnemonic = Bip39MnemonicGenerator().FromWordsNumber(Bip39WordsNum.WORDS_NUM_24)
seed = Bip39SeedGenerator(mnemonic).Generate()


def acc(ctx):
    return ctx.Purpose().Coin().Account(0).PublicKey().ToExtended()


print("=== МНЕМОНИКА (секрет! храни офлайн) ===")
print(mnemonic, "\n")
print("=== Вставь в .env ===")
print("XPUB_TRON=" + acc(Bip44.FromSeed(seed, Bip44Coins.TRON)))
print("XPUB_BTC=" + acc(Bip84.FromSeed(seed, Bip84Coins.BITCOIN)))
print("XPUB_ETH=" + acc(Bip44.FromSeed(seed, Bip44Coins.ETHEREUM)))
